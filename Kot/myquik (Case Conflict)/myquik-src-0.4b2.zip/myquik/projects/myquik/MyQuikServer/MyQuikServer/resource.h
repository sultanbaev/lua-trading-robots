#ifndef IDC_STATIC
#define IDC_STATIC (-1)
#endif

#define IDD_ABOUTBOX                            103
#define IDM_ABOUT                               104
#define IDM_EXIT                                105
#define IDI_MYQUIKSERVER                        107
#define IDR_MENU_TRAY                           129
#define IDM_SHOW                                32778
#define ID_OPTIONS_AUTORUN                      32781
#define ID_OPTIONS_WRITE_MESSAGES_TO_FILE       32795
#define ID_OPTIONS_SYSTRAY_MINIMIZE             32796
#define ID_OPTIONS_SYSTRAY_AUTOHIDE             32797
#define ID_OPTIONS_SYSTRAY_SHOW_ICON            32798
#define ID_OPTIONS_SYSTRAY_CLOSEWINDOW          32799
#define ID_OPTIONS_ENABLE_CACHING               32803
#define IDM_HIDE_IN_TRAY                        40000
#define IDS_APP_TITLE                           40000
#define IDC_MYQUIKSERVER                        40001
#define ID_OPTIONS_PATH_LOG                     40001
