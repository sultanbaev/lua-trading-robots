#pragma once

#ifdef TRANS2QUIK_EXPORTS
#define TRANS2QUIK_API __declspec (dllexport)
#pragma message ("TRANS2QUIK_API defined as __declspec (dllexport)")
#else
//#pragma message ("TRANS2QUIK_API defined as __declspec (dllimport)")
#define TRANS2QUIK_API __declspec (dllimport)
#endif

#ifdef __cplusplus
extern "C" {
#endif

typedef void (__stdcall *TRANS2QUIK_CONNECTION_STATUS_CALLBACK) (long nConnectionEvent, long nExtendedErrorCode, LPCSTR lpcstrInfoMessage);
typedef void (__stdcall *TRANS2QUIK_TRANSACTION_REPLY_CALLBACK) (long nTransactionResult, long nTransactionExtendedErrorCode, long nTransactionReplyCode, DWORD dwTransId, double dOrderNum, LPCSTR lpcstrTransactionReplyMessage);

//typedef void (__stdcall *TRANS2QUIK_CONNECTION_STATUS_CALLBACK) (long nConnectionEvent, long nExtendedErrorCode, LPSTR lpstrInfoMessage);
//typedef void (__stdcall *TRANS2QUIK_TRANSACTION_REPLY_CALLBACK) (long nTransactionResult, long nTransactionExtendedErrorCode, long nTransactionReplyCode, DWORD dwTransId, double dOrderNum, LPSTR lpstrTransactionReplyMessage);

#define TRANS2QUIK_SUCCESS						0
#define TRANS2QUIK_FAILED						1
#define TRANS2QUIK_QUIK_TERMINAL_NOT_FOUND		2
#define TRANS2QUIK_DLL_VERSION_NOT_SUPPORTED	3
#define TRANS2QUIK_ALREADY_CONNECTED_TO_QUIK	4
#define TRANS2QUIK_WRONG_SYNTAX					5
#define TRANS2QUIK_QUIK_NOT_CONNECTED			6
#define TRANS2QUIK_DLL_NOT_CONNECTED			7
#define TRANS2QUIK_QUIK_CONNECTED				8
#define TRANS2QUIK_QUIK_DISCONNECTED			9
#define TRANS2QUIK_DLL_CONNECTED				10
#define TRANS2QUIK_DLL_DISCONNECTED				11
#define TRANS2QUIK_MEMORY_ALLOCATION_ERROR		12
#define TRANS2QUIK_WRONG_CONNECTION_HANDLE		13
#define TRANS2QUIK_WRONG_INPUT_PARAMS			14


long TRANS2QUIK_API __stdcall TRANS2QUIK_SEND_SYNC_TRANSACTION (LPSTR lpstTransactionString, long* pnReplyCode, PDWORD pdwTransId, double* pdOrderNum, LPSTR lpstrResultMessage, DWORD dwResultMessageSize, long* pnExtendedErrorCode, LPSTR lpstErrorMessage, DWORD dwErrorMessageSize);
long TRANS2QUIK_API __stdcall TRANS2QUIK_SEND_ASYNC_TRANSACTION (LPSTR lpstTransactionString, long* pnExtendedErrorCode, LPSTR lpstErrorMessage, DWORD dwErrorMessageSize);
long TRANS2QUIK_API __stdcall TRANS2QUIK_CONNECT (LPSTR lpstConnectionParamsString, long* pnExtendedErrorCode, LPSTR lpstrErrorMessage, DWORD dwErrorMessageSize);
long TRANS2QUIK_API __stdcall TRANS2QUIK_DISCONNECT (long* pnExtendedErrorCode, LPSTR lpstrErrorMessage, DWORD dwErrorMessageSize);
long TRANS2QUIK_API __stdcall TRANS2QUIK_SET_CONNECTION_STATUS_CALLBACK (TRANS2QUIK_CONNECTION_STATUS_CALLBACK pfConnectionStatusCallback, long* pnExtendedErrorCode, LPSTR lpstrErrorMessage, DWORD dwErrorMessageSize);
long TRANS2QUIK_API __stdcall TRANS2QUIK_SET_TRANSACTIONS_REPLY_CALLBACK (TRANS2QUIK_TRANSACTION_REPLY_CALLBACK pfTransactionReplyCallback, long* pnExtendedErrorCode, LPSTR lpstrErrorMessage, DWORD dwErrorMessageSize);
long TRANS2QUIK_API __stdcall TRANS2QUIK_IS_QUIK_CONNECTED (long* pnExtendedErrorCode, LPSTR lpstrErrorMessage, DWORD dwErrorMessageSize);
long TRANS2QUIK_API __stdcall TRANS2QUIK_IS_DLL_CONNECTED (long* pnExtendedErrorCode, LPSTR lpstrErrorMessage, DWORD dwErrorMessageSize);


#ifdef __cplusplus
}
#endif
